//variaveis ator
let xAtor = 100;
let yAtor = 370;
let colisao = false;
let pontos = 0;

function mostraAtor(){
  image(imagemAtor, xAtor, yAtor, 30, 30);
}

function movimentaAtor(){
  if(keyIsDown(UP_ARROW)){
     yAtor -=3;
  }
  if(keyIsDown(DOWN_ARROW)){
    if (yAtor < 370){ 
      yAtor +=3;
      }
  }
  if(keyIsDown(LEFT_ARROW)){
    if (xAtor>0){ 
      xAtor -=3;
    }
}
  if(keyIsDown(RIGHT_ARROW)){
     if (xAtor < 475){
      xAtor +=3;
     }
  }
}

function verificaColisao(){

  for (i=0;i<imagemCarros.length; i++){
    colisao = collideRectCircle(xCarros[i], yCarros[i],comprimentoCarro,alturaCarro,xAtor,yAtor,15);
    if(colisao){
      colidiu();
      somColidiu.play();
      verificaPlacar()
      ;
    }
  }
}
  function colidiu(){
    xAtor = 100;
    yAtor = 370;
}

function placar(){
  textAlign(CENTER);
  textSize(25);
  fill(color(255,240,0));
  text(pontos, width/2,25);
}

function marcaPonto(){
  if(yAtor < 30){
    pontos++;
    somPonto.play();
    colidiu();
  }
}

function verificaPlacar(){
  if(pontos>0){
    pontos-=1;}
}