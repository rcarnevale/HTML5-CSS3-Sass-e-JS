//variaveis carros
let xCarros = [600,600,600,600,600,600]
let yCarros = [40,90,150, 210, 270, 318];
let velocidadeCarros= [2,4,2.5, 3, 2, 3.5]
let comprimentoCarro = 50;
let alturaCarro = 40;

function mostraCarro(){
  for (i=0; i<imagemCarros.length; i++) {
    image(imagemCarros[i], xCarros[i], yCarros[i], comprimentoCarro, alturaCarro);
  }
}

function movimentaCarro(){
  for (i=0; i<imagemCarros.length; i++){
    xCarros[i] -= velocidadeCarros[i];
  }
}

function respawnCarro(){
  for (i=0; i<imagemCarros.length;i++){
    if(passouTela(xCarros[i])){
    xCarros[i] = 600;
  }
}
}

function passouTela(xCarro){
  return xCarro <  -50;
}
