//variaveis imagens
let imagemEstrada;
let imagemAtor;
let imagemCarro;
let imagemCarro2;
let imagemCarro3;

let somTrilha;
let somColidiu;
let somPonto;

function preload(){
  imagemEstrada = loadImage("Imagem/estrada.png");
  imagemAtor = loadImage("Imagem/ator-1.png");
  imagemCarro = loadImage("Imagem/carro-1.png");
  imagemCarro2 = loadImage("Imagem/carro-2.png");
  imagemCarro3 = loadImage("Imagem/carro-3.png");
  imagemCarros = [imagemCarro,imagemCarro2, imagemCarro3, imagemCarro2, imagemCarro, imagemCarro3];
  
  somTrilha = loadSound("sons/trilha.mp3");
  somColidiu = loadSound("sons/colidiu.mp3");
  somPonto = loadSound("sons/pontos.wav");
}
